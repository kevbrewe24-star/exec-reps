import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { openDb } from '../src/db.js';
import { validateScenario } from '../src/schema.js';
import { dailyScenarioId, bonusScenarioId, recordAnswer, streak, saveProfile, xpFor } from '../src/practice.js';
import { makeGrader } from '../src/grader.js';
import { parseFeed, generate } from '../src/generate.js';
import { parseJson } from '../src/llm.js';
import { createApp } from '../server.js';

const seed = JSON.parse(readFileSync(new URL('../data/seed/scenarios.json', import.meta.url)));

test('every seed scenario is valid and best answers are spread across letters', () => {
  for (const s of seed) assert.deepEqual(validateScenario(s), [], s.id);
  assert.ok(new Set(seed.map(s => s.best)).size >= 3);
  assert.equal(new Set(seed.map(s => s.id)).size, seed.length);
});

test('daily pick is stable within a day and rotates tracks across days', () => {
  const db = openDb(':memory:');
  const d1 = dailyScenarioId(db, '2026-12-01');
  assert.equal(dailyScenarioId(db, '2026-12-01'), d1);
  const tracks = new Set(['2026-12-01', '2026-12-02', '2026-12-03'].map(d =>
    db.prepare('SELECT track FROM scenario WHERE id = ?').get(dailyScenarioId(db, d)).track));
  assert.equal(tracks.size, 3);
});

test('streak counts consecutive days and survives until the day is missed', async () => {
  const db = openDb(':memory:');
  for (const day of ['2026-12-01', '2026-12-02', '2026-12-03']) {
    await recordAnswer(db, { scenarioId: dailyScenarioId(db, day), choice: 'a' }, { day });
  }
  assert.deepEqual(streak(db, '2026-12-03'), { current: 3, doneToday: true });
  assert.deepEqual(streak(db, '2026-12-04'), { current: 3, doneToday: false }); // still alive today
  assert.deepEqual(streak(db, '2026-12-05'), { current: 0, doneToday: false }); // missed the 4th
});

test('answer scoring, daily flag and bonus reps', async () => {
  const db = openDb(':memory:');
  const day = '2026-12-01';
  const id = dailyScenarioId(db, day);
  const s = seed.find(x => x.id === id);
  const r = await recordAnswer(db, { scenarioId: id, choice: s.best }, { day });
  assert.equal(r.score, 3);
  assert.equal(r.isDaily, true);
  assert.equal(r.xp, 40);
  const again = await recordAnswer(db, { scenarioId: id, choice: s.best }, { day });
  assert.equal(again.isDaily, false); // redo doesn't count twice
  const b = bonusScenarioId(db, day);
  assert.ok(b && b !== id);
  await assert.rejects(recordAnswer(db, { scenarioId: id, choice: 'z' }, { day }), /Unknown option/);
});

test('profile tracks limit the daily rotation', () => {
  const db = openDb(':memory:');
  saveProfile(db, { name: 'Sam', tracks: ['incident'] });
  for (const d of ['2026-12-01', '2026-12-02', '2026-12-03']) {
    const id = dailyScenarioId(db, d);
    assert.ok(id.startsWith('inc-'), id);
  }
  assert.throws(() => saveProfile(db, { tracks: ['nope'] }), /at least one track/);
});

test('grader: self-check without a key, clamps AI scores with a key', async () => {
  const s = seed[0];
  const self = await makeGrader({ enabled: false })(s, 'some answer');
  assert.equal(self.mode, 'self');
  assert.equal(self.scores.length, s.rubric.length);

  const ai = await makeGrader({
    enabled: true,
    ask: async () => ({ scores: [{ criterion: s.rubric[0].criterion, score: 2, comment: 'good' }, { criterion: s.rubric[1].criterion, score: 9 }], strongest: 'x', improve: 'y', rewrite: 'z' })
  })(s, 'answer');
  assert.equal(ai.mode, 'ai');
  assert.deepEqual(ai.scores.map(x => x.score), [2, 0, 0, 0]);
  assert.equal(xpFor(3, ai, 'x'.repeat(50)), 40 + 10 + 4);

  const failing = await makeGrader({ enabled: true, ask: async () => { throw new Error('boom'); } })(s, 'answer');
  assert.equal(failing.mode, 'self');
  assert.match(failing.error, /boom/);
});

test('feed parsing handles RSS, Atom and CDATA', () => {
  const rss = '<rss><channel><item><title><![CDATA[Port strike &amp; delays]]></title><link>https://ex.com/a</link></item></channel></rss>';
  const atom = '<feed><entry><title>Outage report</title><link href="https://ex.com/b"/></entry></feed>';
  assert.deepEqual(parseFeed(rss), [{ title: 'Port strike & delays', url: 'https://ex.com/a' }]);
  assert.deepEqual(parseFeed(atom), [{ title: 'Outage report', url: 'https://ex.com/b' }]);
  assert.deepEqual(parseJson('```json\n{"a":1}\n```'), { a: 1 });
});

test('generator validates output, keeps only real source links, and saves', async () => {
  const db = openDb(':memory:');
  const feedXml = '<rss><item><title>Supplier fire halts chip plant</title><link>https://news.example/fire</link></item></rss>';
  const fake = structuredClone(seed.find(s => s.track === 'ops'));
  fake.title = 'A brand new ops dilemma';
  fake.sources = [{ title: 'real', url: 'https://news.example/fire' }, { title: 'made up', url: 'https://invented.example/x' }];
  const broken = { title: 'Broken one', options: [] };
  const r = await generate({
    track: 'ops', count: 2, db, feeds: ['https://feed.example/rss'],
    fetchImpl: async () => ({ ok: true, text: async () => feedXml }),
    ask: async () => [fake, broken]
  });
  assert.equal(r.saved.length, 1);
  assert.equal(r.rejected.length, 1);
  const saved = JSON.parse(db.prepare('SELECT body FROM scenario WHERE id = ?').get(r.saved[0]).body);
  assert.deepEqual(saved.sources.map(s => s.url), ['https://news.example/fire']);
});

test('HTTP API end to end', async () => {
  const server = createApp({ db: openDb(':memory:'), grader: makeGrader({ enabled: false }) }).listen(0);
  const base = `http://localhost:${server.address().port}`;
  try {
    const today = await (await fetch(`${base}/api/today`)).json();
    assert.ok(today.scenario.options.every(o => !('score' in o) && !('why' in o)), 'answers must not leak');
    const ans = await (await fetch(`${base}/api/answer`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ scenarioId: today.scenario.id, choice: 'b', written: 'I would tell my boss first.' })
    })).json();
    assert.equal(ans.streak.current, 1);
    assert.equal(ans.grade.mode, 'self');
    const me = await (await fetch(`${base}/api/me`)).json();
    assert.equal(me.reps, 1);
    assert.equal((await fetch(`${base}/`)).status, 200);
    assert.equal((await fetch(`${base}/../package.json`)).status, 404);
    assert.equal((await fetch(`${base}/api/answer`, { method: 'POST', body: '{bad' })).status, 400);
  } finally {
    server.close();
  }
});
