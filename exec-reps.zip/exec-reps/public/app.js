const app = document.getElementById('app');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const api = async (path, body) => {
  const res = await fetch(path, body ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : {});
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
};

let state = { tab: 'today', today: null, current: null, picked: null, result: null, busy: false, error: '' };

function setMeters(streak, xp) {
  if (streak) document.getElementById('streakN').textContent = streak.current;
  if (xp !== undefined) document.getElementById('xp').textContent = `${xp} XP`;
}

document.querySelectorAll('.tabs button').forEach(b => b.addEventListener('click', () => {
  document.querySelectorAll('.tabs button').forEach(x => x.classList.toggle('on', x === b));
  state.tab = b.dataset.tab;
  render();
}));

async function loadToday() {
  const t = await api('/api/today');
  state.today = t;
  state.current = t.scenario;
  state.picked = null;
  state.result = null;
  setMeters(t.streak, t.xp);
}

function difficulty(n) { return ['', 'Warm-up', 'Standard', 'Hard'][n] || ''; }

function scenarioView(s, aiGrading, isBonus) {
  const opts = s.options.map(o => `
    <button type="button" class="opt" data-opt="${esc(o.id)}" aria-pressed="${state.picked === o.id}">
      <span class="letter">${esc(o.id)}</span><span>${esc(o.text)}</span>
    </button>`).join('');
  return `
    <article class="card">
      <div class="meta">
        <span class="chip">${esc(s.trackName)}</span>
        <span>${difficulty(s.difficulty)}</span>
        <span>· ${isBonus ? 'Bonus rep' : "Today's rep"}</span>
      </div>
      <h1>${esc(s.title)}</h1>
      <p class="situation">${esc(s.situation)}</p>
      <p class="question">${esc(s.question)}</p>
    </article>
    <fieldset class="options" aria-label="Your call">${opts}</fieldset>
    <label class="field">Explain your call
      <small>Optional, worth extra XP. ${aiGrading ? 'Graded by AI against: ' : 'Check yourself against: '}${esc(s.rubric.join(' · '))}.</small>
      <textarea id="written" maxlength="4000" placeholder="What you'd do first, who you'd tell, and why.">${esc(state.draft || '')}</textarea>
    </label>
    ${state.error ? `<p class="error">${esc(state.error)}</p>` : ''}
    <div class="row"><button type="button" class="btn" id="submit" ${state.picked && !state.busy ? '' : 'disabled'}>${state.busy ? 'Scoring…' : 'Lock in my call'}</button></div>`;
}

function resultView(r) {
  const verdict = r.score === 3 ? ['good', 'Strong call'] : r.score === 2 ? ['mid', 'Partly there'] : ['bad', 'Not the best move'];
  const explain = r.options.map(o => {
    const tags = [o.id === r.best ? '<span class="tag best">Best move</span>' : '', o.id === r.choice ? '<span class="tag yours">Your pick</span>' : ''].filter(Boolean).join(' · ');
    return `<div class="item ${o.id === r.best ? 'best' : ''}">
      ${tags ? `<div>${tags}</div>` : ''}
      <strong>${esc(o.id.toUpperCase())}. ${esc(o.text)}</strong>
      <p>${esc(o.why)}</p></div>`;
  }).join('');

  let grade = '';
  if (r.grade) {
    const rows = r.grade.scores.map(g => `
      <div class="r">
        ${g.score === null ? '<span class="dots" aria-hidden="true"><i></i></span>'
          : `<span class="dots" role="img" aria-label="${g.score} of 2">${[0, 1].map(i => `<i class="${i < g.score ? 'on' : ''}"></i>`).join('')}</span>`}
        <div><strong>${esc(g.criterion)}</strong><div class="muted">${esc(g.comment)}</div></div>
      </div>`).join('');
    grade = `<section class="card"><h2>${r.grade.mode === 'ai' ? 'Your written answer' : 'Check your written answer'}</h2>
      <div class="rubric">${rows}</div>
      ${r.grade.strongest ? `<p><strong>Strongest:</strong> ${esc(r.grade.strongest)}</p>` : ''}
      ${r.grade.improve ? `<p><strong>Next time:</strong> ${esc(r.grade.improve)}</p>` : ''}
      ${r.grade.rewrite ? `<p><strong>A stronger version:</strong> ${esc(r.grade.rewrite)}</p>` : ''}
      ${r.grade.error ? `<p class="muted">${esc(r.grade.error)}</p>` : ''}</section>`;
  }

  const sources = r.sources.length ? `<section class="card sources"><h2>Inspired by</h2><ul class="moves">${r.sources.map(s => `<li><a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.title)}</a></li>`).join('')}</ul></section>` : '';

  return `
    <div class="verdict ${verdict[0]}">
      <div><strong>${verdict[1]}</strong>${r.isDaily ? `Daily rep done · ${r.streak.current}-day streak` : 'Bonus rep done'}</div>
      <span class="gain">+${r.xp} XP</span>
    </div>
    <section class="card"><h2>${esc(state.current.title)}</h2><div class="explain">${explain}</div></section>
    <section class="card"><h2>What strong leaders do</h2><ul class="moves">${r.keyMoves.map(m => `<li>${esc(m)}</li>`).join('')}</ul></section>
    ${grade}${sources}
    <div class="row">
      <button type="button" class="btn" id="bonus">Do a bonus rep</button>
      <button type="button" class="btn ghost" id="progress">See my progress</button>
    </div>`;
}

async function renderToday() {
  if (!state.today) await loadToday();
  const t = state.today;
  if (state.result) { app.innerHTML = resultView(state.result); bindResult(); return; }
  if (!state.current) { app.innerHTML = '<div class="card"><h2>All caught up</h2><p class="muted">You have done every scenario in your tracks. Run <code>npm run generate</code> to add fresh ones.</p></div>'; return; }
  const header = t.streak.doneToday && state.current.id === t.scenario.id
    ? '<p class="muted">You already did today\'s rep. Redoing it is good practice; it won\'t change your streak.</p>' : '';
  app.innerHTML = header + scenarioView(state.current, t.aiGrading, state.current.id !== t.scenario.id);
  app.querySelectorAll('.opt').forEach(b => b.addEventListener('click', () => {
    state.draft = document.getElementById('written').value;
    state.picked = b.dataset.opt;
    renderToday();
  }));
  document.getElementById('submit').addEventListener('click', submit);
}

async function submit() {
  const written = document.getElementById('written').value;
  state.draft = written; state.busy = true; state.error = ''; renderToday();
  try {
    state.result = await api('/api/answer', { scenarioId: state.current.id, choice: state.picked, written });
    state.today.streak = state.result.streak;
    const me = await api('/api/me');
    setMeters(state.result.streak, me.xp);
    state.draft = '';
  } catch (e) {
    state.error = e.message;
  }
  state.busy = false;
  renderToday();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function bindResult() {
  document.getElementById('bonus').addEventListener('click', async () => {
    const { scenario } = await api('/api/bonus');
    state.current = scenario; state.picked = null; state.result = null;
    renderToday();
    window.scrollTo({ top: 0 });
  });
  document.getElementById('progress').addEventListener('click', () => document.querySelector('[data-tab=progress]').click());
}

async function renderProgress() {
  const me = await api('/api/me');
  setMeters(me.streak, me.xp);
  const rows = me.byTrack.map(t => `<tr><td>${esc(me.tracks[t.track] || t.track)}</td><td>${t.reps}</td><td>${Math.round(t.avgScore / 3 * 100)}%</td></tr>`).join('')
    || '<tr><td colspan="3" class="muted">No reps yet.</td></tr>';
  const recent = me.recent.map(r => `<tr><td>${esc(r.day)}</td><td>${esc(r.title)}</td><td>+${r.xp}</td></tr>`).join('');
  app.innerHTML = `
    <div class="stats">
      <div class="stat"><b>${me.streak.current}</b><span>day streak</span></div>
      <div class="stat"><b>${me.reps}</b><span>reps done</span></div>
      <div class="stat"><b>${me.xp}</b><span>total XP</span></div>
    </div>
    <section class="card"><h2>By track</h2>
      <table><thead><tr><th>Track</th><th>Reps</th><th>Avg. call quality</th></tr></thead><tbody>${rows}</tbody></table></section>
    ${recent ? `<section class="card"><h2>Recent</h2><table><tbody>${recent}</tbody></table></section>` : ''}`;
}

async function renderSettings() {
  const me = await api('/api/me');
  const checks = Object.entries(me.tracks).map(([id, name]) =>
    `<label><input type="checkbox" name="track" value="${esc(id)}" ${me.profile.tracks.includes(id) ? 'checked' : ''}> ${esc(name)}</label>`).join('');
  app.innerHTML = `
    <section class="card">
      <h2>Your practice</h2>
      <label class="field">Name<input type="text" id="name" value="${esc(me.profile.name)}" maxlength="60"></label>
      <p class="muted">Daily reps rotate through the tracks you pick.</p>
      <div class="checks">${checks}</div>
      <p id="msg" class="muted" role="status"></p>
      <div class="row"><button type="button" class="btn" id="save">Save</button></div>
    </section>`;
  document.getElementById('save').addEventListener('click', async () => {
    const tracks = [...app.querySelectorAll('input[name=track]:checked')].map(i => i.value);
    const msg = document.getElementById('msg');
    try {
      await api('/api/profile', { name: document.getElementById('name').value, tracks });
      msg.textContent = 'Saved. New tracks apply from tomorrow\'s rep.';
    } catch (e) { msg.textContent = e.message; msg.className = 'error'; }
  });
}

async function render() {
  try {
    if (state.tab === 'today') await renderToday();
    else if (state.tab === 'progress') await renderProgress();
    else await renderSettings();
  } catch (e) {
    app.innerHTML = `<div class="card"><p class="error">${esc(e.message)}</p></div>`;
  }
}

render();
