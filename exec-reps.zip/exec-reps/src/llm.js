// Minimal Claude API client using built-in fetch. No SDK dependency.

export const MODEL = process.env.EXEC_REPS_MODEL || 'claude-sonnet-5-5';

export function hasKey() {
  return !!process.env.ANTHROPIC_API_KEY;
}

export async function askJson({ system, prompt, maxTokens = 2000, fetchImpl = fetch }) {
  const res = await fetchImpl('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: maxTokens,
      system,
      messages: [{ role: 'user', content: prompt }]
    })
  });
  if (!res.ok) throw new Error(`Claude API ${res.status}: ${(await res.text()).slice(0, 300)}`);
  const data = await res.json();
  const text = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
  return parseJson(text);
}

export function parseJson(text) {
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  const start = cleaned.search(/[[{]/);
  if (start < 0) throw new Error('No JSON in model output');
  return JSON.parse(cleaned.slice(start));
}
