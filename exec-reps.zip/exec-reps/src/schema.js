// Shape of a scenario, shared by the seed pack, the generator and the tests.

export const TRACKS = {
  revenue: 'Revenue & forecasting',
  ops: 'Operations & procurement',
  incident: 'Incident leadership'
};

export function validateScenario(s) {
  const errors = [];
  const need = (cond, msg) => { if (!cond) errors.push(msg); };

  need(s && typeof s === 'object', 'scenario must be an object');
  if (errors.length) return errors;

  need(typeof s.id === 'string' && /^[a-z0-9-]{3,64}$/.test(s.id), 'id: lowercase letters, digits, dashes');
  need(Object.hasOwn(TRACKS, s.track), `track must be one of ${Object.keys(TRACKS).join(', ')}`);
  need(typeof s.title === 'string' && s.title.length >= 5 && s.title.length <= 80, 'title: 5-80 chars');
  need([1, 2, 3].includes(s.difficulty), 'difficulty: 1, 2 or 3');
  need(typeof s.situation === 'string' && s.situation.length >= 150 && s.situation.length <= 1200, 'situation: 150-1200 chars');
  need(typeof s.question === 'string' && s.question.length >= 10, 'question required');

  need(Array.isArray(s.options) && s.options.length === 4, 'exactly 4 options');
  if (Array.isArray(s.options)) {
    const ids = s.options.map(o => o && o.id);
    need(new Set(ids).size === ids.length, 'option ids must be unique');
    s.options.forEach((o, i) => {
      need(o && typeof o.text === 'string' && o.text.length > 0, `option ${i}: text`);
      need(o && [0, 1, 2, 3].includes(o.score), `option ${i}: score 0-3`);
      need(o && typeof o.why === 'string' && o.why.length > 0, `option ${i}: why`);
    });
    const best = s.options.find(o => o && o.id === s.best);
    need(!!best, 'best must name an option id');
    if (best) need(best.score === Math.max(...s.options.map(o => o.score)), 'best must have the top score');
    need(s.options.filter(o => o && o.score === 3).length === 1, 'exactly one option scores 3');
  }

  need(Array.isArray(s.keyMoves) && s.keyMoves.length >= 2, 'keyMoves: at least 2');
  need(Array.isArray(s.rubric) && s.rubric.length >= 3 && s.rubric.length <= 5, 'rubric: 3-5 criteria');
  if (Array.isArray(s.rubric)) {
    s.rubric.forEach((r, i) => need(r && r.criterion && r.lookFor, `rubric ${i}: criterion and lookFor`));
  }
  if (s.sources !== undefined) {
    need(Array.isArray(s.sources) && s.sources.every(x => x && /^https?:\/\//.test(x.url || '')), 'sources: [{title,url}] with http(s) urls');
  }
  return errors;
}
