// Daily pick, streaks, XP and answer scoring.
import { getScenario } from './db.js';
import { TRACKS } from './schema.js';

export function localDay(d = new Date()) {
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function dayNumber(day) {
  return Math.floor(Date.UTC(...day.split('-').map((v, i) => (i === 1 ? v - 1 : +v))) / 86400000);
}

function addDays(day, n) {
  const t = new Date(Date.UTC(...day.split('-').map((v, i) => (i === 1 ? v - 1 : +v))) + n * 86400000);
  return t.toISOString().slice(0, 10);
}

export function getProfile(db) {
  const row = db.prepare('SELECT name, tracks FROM profile WHERE id = 1').get();
  let tracks = [];
  try { tracks = JSON.parse(row.tracks).filter(t => Object.hasOwn(TRACKS, t)); } catch { /* fall through */ }
  if (!tracks.length) tracks = Object.keys(TRACKS);
  return { name: row.name || '', tracks };
}

export function saveProfile(db, { name, tracks }) {
  const clean = (Array.isArray(tracks) ? tracks : []).filter(t => Object.hasOwn(TRACKS, t));
  if (!clean.length) throw new Error('Pick at least one track');
  db.prepare('UPDATE profile SET name = ?, tracks = ? WHERE id = 1')
    .run(String(name || '').slice(0, 60), JSON.stringify(clean));
  return getProfile(db);
}

// Pick the next scenario in a track: never-attempted first, then least recently attempted.
function nextInTrack(db, track, excludeIds = []) {
  const rows = db.prepare(`
    SELECT s.id, MAX(a.created_at) AS last, COUNT(a.id) AS n
    FROM scenario s LEFT JOIN attempt a ON a.scenario_id = s.id
    WHERE s.track = ?
    GROUP BY s.id
    ORDER BY n = 0 DESC, last ASC, s.created_at ASC, s.id ASC
  `).all(track);
  const pick = rows.find(r => !excludeIds.includes(r.id));
  return pick ? pick.id : null;
}

// The daily rep is fixed for the whole day once chosen. Tracks rotate by date.
export function dailyScenarioId(db, day = localDay()) {
  const existing = db.prepare('SELECT scenario_id FROM daily WHERE day = ?').get(day);
  if (existing) return existing.scenario_id;
  const { tracks } = getProfile(db);
  const start = dayNumber(day) % tracks.length;
  let id = null;
  for (let i = 0; i < tracks.length && !id; i++) id = nextInTrack(db, tracks[(start + i) % tracks.length]);
  if (!id) throw new Error('No scenarios available');
  db.prepare('INSERT INTO daily (day, scenario_id) VALUES (?, ?)').run(day, id);
  return id;
}

// A bonus rep: another scenario from the user's tracks, not today's daily.
export function bonusScenarioId(db, day = localDay()) {
  const { tracks } = getProfile(db);
  const daily = dailyScenarioId(db, day);
  const doneToday = db.prepare('SELECT scenario_id FROM attempt WHERE day = ?').all(day).map(r => r.scenario_id);
  const exclude = [daily, ...doneToday];
  const start = (dayNumber(day) + 1 + doneToday.length) % tracks.length;
  for (let i = 0; i < tracks.length; i++) {
    const id = nextInTrack(db, tracks[(start + i) % tracks.length], exclude);
    if (id) return id;
  }
  return null;
}

export function streak(db, day = localDay()) {
  const days = new Set(db.prepare('SELECT DISTINCT day FROM attempt').all().map(r => r.day));
  // Today not done yet? The streak is still alive from yesterday.
  let cursor = days.has(day) ? day : addDays(day, -1);
  let n = 0;
  while (days.has(cursor)) { n++; cursor = addDays(cursor, -1); }
  return { current: n, doneToday: days.has(day) };
}

export function stats(db, day = localDay()) {
  const total = db.prepare('SELECT COALESCE(SUM(xp),0) AS xp, COUNT(*) AS reps FROM attempt').get();
  const byTrack = db.prepare(`
    SELECT s.track, COUNT(*) AS reps, ROUND(AVG(a.score), 2) AS avgScore
    FROM attempt a JOIN scenario s ON s.id = a.scenario_id GROUP BY s.track
  `).all();
  const recent = db.prepare(`
    SELECT a.day, a.score, a.xp, s.title, s.track FROM attempt a JOIN scenario s ON s.id = a.scenario_id
    ORDER BY a.id DESC LIMIT 10
  `).all();
  return { xp: total.xp, reps: total.reps, streak: streak(db, day), byTrack, recent };
}

// What the client sees before answering: no scores, no explanations.
export function publicScenario(s) {
  return {
    id: s.id, track: s.track, trackName: TRACKS[s.track], title: s.title, difficulty: s.difficulty,
    situation: s.situation, question: s.question,
    options: s.options.map(o => ({ id: o.id, text: o.text })),
    rubric: s.rubric.map(r => r.criterion)
  };
}

export function xpFor(score, grade, written) {
  let xp = 10 + score * 10;                               // 10-40 for the pick
  if (written && written.trim().length >= 40) xp += 10;   // wrote a real answer
  if (grade && Array.isArray(grade.scores)) {
    xp += grade.scores.reduce((a, s) => a + (Number(s.score) || 0), 0) * 2;  // up to +20 for rubric
  }
  return xp;
}

export async function recordAnswer(db, { scenarioId, choice, written }, { grader, day = localDay() } = {}) {
  const s = getScenario(db, scenarioId);
  if (!s) throw Object.assign(new Error('Unknown scenario'), { status: 404 });
  const picked = s.options.find(o => o.id === choice);
  if (!picked) throw Object.assign(new Error('Unknown option'), { status: 400 });

  const isDaily = dailyScenarioId(db, day) === s.id &&
    !db.prepare('SELECT 1 FROM attempt WHERE day = ? AND is_daily = 1').get(day);

  const text = typeof written === 'string' ? written.slice(0, 4000) : '';
  const grade = text.trim() && grader ? await grader(s, text) : null;
  const xp = xpFor(picked.score, grade, text);

  db.prepare(`INSERT INTO attempt (scenario_id, day, is_daily, choice, written, score, grade, xp)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(s.id, day, isDaily ? 1 : 0, choice, text || null, picked.score, grade ? JSON.stringify(grade) : null, xp);

  return {
    scenarioId: s.id,
    choice,
    score: picked.score,
    best: s.best,
    options: s.options,
    keyMoves: s.keyMoves,
    rubric: s.rubric,
    sources: s.sources || [],
    grade,
    xp,
    isDaily,
    streak: streak(db, day)
  };
}
