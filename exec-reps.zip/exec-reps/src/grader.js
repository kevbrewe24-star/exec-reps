// Grades a written answer against the scenario's rubric.
// With ANTHROPIC_API_KEY set, Claude scores each criterion 0-2.
// Without it, the rubric comes back as a self-check list (scores = null).
import { askJson, hasKey } from './llm.js';

const SYSTEM = `You are an exacting but encouraging executive coach for directors and VPs.
Grade the leader's written answer to a business scenario against the rubric.
Score each criterion 0 (missing), 1 (partly there) or 2 (clearly addressed).
Be specific: quote or paraphrase what they wrote. Never invent facts about their company.
Return ONLY JSON: {"scores":[{"criterion":string,"score":0|1|2,"comment":string}],"strongest":string,"improve":string,"rewrite":string}
"rewrite" is a 2-4 sentence stronger version of their answer, in their voice.`;

export function makeGrader({ ask = askJson, enabled = hasKey() } = {}) {
  return async function grade(scenario, written) {
    if (!enabled) return selfCheck(scenario);
    try {
      const out = await ask({
        system: SYSTEM,
        prompt: JSON.stringify({
          scenario: { title: scenario.title, situation: scenario.situation, question: scenario.question },
          rubric: scenario.rubric,
          answer: written
        }),
        maxTokens: 1200
      });
      const scores = scenario.rubric.map(r => {
        const hit = (out.scores || []).find(s => s.criterion === r.criterion) || {};
        const n = Number(hit.score);
        return { criterion: r.criterion, score: [0, 1, 2].includes(n) ? n : 0, comment: String(hit.comment || '') };
      });
      return { mode: 'ai', scores, strongest: String(out.strongest || ''), improve: String(out.improve || ''), rewrite: String(out.rewrite || '') };
    } catch (err) {
      return { ...selfCheck(scenario), error: `AI grading unavailable: ${err.message}` };
    }
  };
}

function selfCheck(scenario) {
  return {
    mode: 'self',
    scores: scenario.rubric.map(r => ({ criterion: r.criterion, score: null, comment: r.lookFor })),
    strongest: '',
    improve: 'Check your answer against each point. Add ANTHROPIC_API_KEY to get scored AI feedback.',
    rewrite: ''
  };
}
