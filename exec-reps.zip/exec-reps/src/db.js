import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { validateScenario } from './schema.js';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
export const DEFAULT_DB = process.env.EXEC_REPS_DB || join(ROOT, 'data', 'exec-reps.db');
const SEED = join(ROOT, 'data', 'seed', 'scenarios.json');

export function openDb(path = DEFAULT_DB) {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec(`
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS profile (
      id          INTEGER PRIMARY KEY CHECK (id = 1),
      name        TEXT,
      tracks      TEXT NOT NULL DEFAULT '["revenue","ops","incident"]',
      created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS scenario (
      id          TEXT PRIMARY KEY,
      track       TEXT NOT NULL,
      title       TEXT NOT NULL,
      difficulty  INTEGER NOT NULL,
      body        TEXT NOT NULL,              -- full scenario JSON
      source      TEXT NOT NULL CHECK (source IN ('seed','generated')),
      created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS daily (
      day          TEXT PRIMARY KEY,          -- YYYY-MM-DD, local time
      scenario_id  TEXT NOT NULL REFERENCES scenario(id)
    );
    CREATE TABLE IF NOT EXISTS attempt (
      id           INTEGER PRIMARY KEY,
      scenario_id  TEXT NOT NULL REFERENCES scenario(id),
      day          TEXT NOT NULL,
      is_daily     INTEGER NOT NULL DEFAULT 0,
      choice       TEXT NOT NULL,
      written      TEXT,
      score        INTEGER NOT NULL,           -- 0-3 from the chosen option
      grade        TEXT,                       -- AI rubric grading JSON, if any
      xp           INTEGER NOT NULL,
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_attempt_day ON attempt(day);
    INSERT OR IGNORE INTO profile (id) VALUES (1);
  `);
  seed(db);
  return db;
}

function seed(db) {
  const list = JSON.parse(readFileSync(SEED, 'utf8'));
  const ins = db.prepare(`INSERT OR IGNORE INTO scenario (id, track, title, difficulty, body, source)
                          VALUES (?, ?, ?, ?, ?, 'seed')`);
  for (const s of list) {
    const errs = validateScenario(s);
    if (errs.length) throw new Error(`Seed scenario ${s.id} invalid: ${errs.join('; ')}`);
    ins.run(s.id, s.track, s.title, s.difficulty, JSON.stringify(s));
  }
}

export function insertScenario(db, s, source = 'generated') {
  const errs = validateScenario(s);
  if (errs.length) throw new Error(`Invalid scenario: ${errs.join('; ')}`);
  db.prepare(`INSERT INTO scenario (id, track, title, difficulty, body, source) VALUES (?, ?, ?, ?, ?, ?)`)
    .run(s.id, s.track, s.title, s.difficulty, JSON.stringify(s), source);
}

export function getScenario(db, id) {
  const row = db.prepare('SELECT body FROM scenario WHERE id = ?').get(id);
  return row ? JSON.parse(row.body) : null;
}
