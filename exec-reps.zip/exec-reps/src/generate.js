// Generates fresh scenarios from current headlines.
//   node src/generate.js --track ops --count 2
// Reads headline titles and links from config/feeds.json, asks Claude for ORIGINAL
// scenarios inspired by those trends, validates them, and saves them to the database.
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDb, insertScenario } from './db.js';
import { TRACKS, validateScenario } from './schema.js';
import { askJson, hasKey } from './llm.js';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');

export function parseFeed(xml) {
  const items = [];
  const blocks = xml.match(/<(item|entry)\b[\s\S]*?<\/\1>/gi) || [];
  for (const b of blocks) {
    const title = decode((b.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || '');
    const link = decode(
      (b.match(/<link\b[^>]*href="([^"]+)"/i) || [])[1] ||
      (b.match(/<link\b[^>]*>([\s\S]*?)<\/link>/i) || [])[1] || ''
    );
    if (title && /^https?:\/\//.test(link)) items.push({ title: title.slice(0, 200), url: link });
  }
  return items;
}

function decode(s) {
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").trim();
}

export async function headlinesFor(track, { fetchImpl = fetch, feeds } = {}) {
  const list = feeds || JSON.parse(readFileSync(join(ROOT, 'config', 'feeds.json'), 'utf8'))[track] || [];
  const out = [];
  for (const url of list) {
    try {
      const res = await fetchImpl(url, { headers: { 'user-agent': 'exec-reps/0.1 (+headline reader)' } });
      if (res.ok) out.push(...parseFeed(await res.text()).slice(0, 12));
      else console.warn(`feed ${url}: HTTP ${res.status}`);
    } catch (e) {
      console.warn(`feed ${url}: ${e.message}`);
    }
  }
  return out;
}

const SYSTEM = `You write realistic practice scenarios for directors and VPs, in the style of a short business case.
Use the headlines only as inspiration for current pressures. Do NOT copy or summarize any article, do not name
real companies or people, and invent a plausible fictional situation with concrete numbers.
Each scenario has exactly 4 options: one clearly best (score 3), one decent but flawed (score 2), and two weaker (scores 0-1).
Vary which option letter is best. Explanations ("why") say what each option gets right or wrong in 1-2 sentences.
Return ONLY a JSON array of scenario objects with this shape:
{"id": "<track>-gen-<short-slug>", "track": string, "title": string (<=80 chars), "difficulty": 1|2|3,
 "situation": string (400-900 chars), "question": string,
 "options": [{"id":"a"|"b"|"c"|"d","text":string,"score":0-3,"why":string}],
 "best": "<option id>", "keyMoves": [3-4 strings], "rubric": [{"criterion":string,"lookFor":string}] (4 items),
 "sources": [{"title": string, "url": string}]  // 1-3 of the headlines that inspired it, copied exactly}`;

export async function generate({ track, count = 1, db, ask = askJson, fetchImpl = fetch, feeds } = {}) {
  if (!Object.hasOwn(TRACKS, track)) throw new Error(`--track must be one of: ${Object.keys(TRACKS).join(', ')}`);
  const heads = await headlinesFor(track, { fetchImpl, feeds });
  if (!heads.length) throw new Error('No headlines fetched; check config/feeds.json and your network');

  const out = await ask({
    system: SYSTEM,
    prompt: JSON.stringify({ track, trackName: TRACKS[track], count, headlines: heads.slice(0, 20) }),
    maxTokens: 4000 * count
  });
  const list = Array.isArray(out) ? out : [out];
  const allowed = new Set(heads.map(h => h.url));
  const saved = [], rejected = [];
  for (const s of list) {
    s.track = track;
    s.sources = (s.sources || []).filter(x => x && allowed.has(x.url)); // only links we actually fetched
    const slug = String(s.title || 'scenario').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 36);
    s.id = `${track}-gen-${slug}-${Date.now().toString(36)}${saved.length}`;
    const errs = validateScenario(s);
    if (errs.length) { rejected.push({ title: s.title, errors: errs }); continue; }
    insertScenario(db, s, 'generated');
    saved.push(s.id);
  }
  return { saved, rejected };
}

// CLI
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const arg = k => { const i = process.argv.indexOf(`--${k}`); return i > 0 ? process.argv[i + 1] : undefined; };
  if (!hasKey()) { console.error('Set ANTHROPIC_API_KEY first (see .env.example).'); process.exit(1); }
  const tracks = arg('track') ? [arg('track')] : Object.keys(TRACKS);
  const count = Math.max(1, Math.min(5, Number(arg('count') || 1)));
  const db = openDb();
  for (const track of tracks) {
    try {
      const r = await generate({ track, count, db });
      console.log(`${track}: saved ${r.saved.length}`, r.saved);
      for (const x of r.rejected) console.warn(`  rejected "${x.title}": ${x.errors.join('; ')}`);
    } catch (e) {
      console.error(`${track}: ${e.message}`);
      process.exitCode = 1;
    }
  }
}
